#!/bin/bash
# Helper script to create a private repo on GitHub (using gh CLI), push code, and enable Actions.
# Requirements:
# 1) Install Git and GitHub CLI (gh): https://cli.github.com/
# 2) Authenticate: gh auth login
# 3) Run this script from local machine where this repo is extracted.
#
# Usage:
#   ./push_to_github.sh unseen-arena notvinodff-lgtm main
#
REPO_NAME=${1:-unseen-arena}
GH_USER=${2:-notvinodff-lgtm}
BRANCH=${3:-main}

echo "Creating repo $GH_USER/$REPO_NAME (private)..."
gh repo create "$GH_USER/$REPO_NAME" --private --confirm || { echo "Repo create failed or already exists"; exit 1; }

git init
git add .
git commit -m "Initial commit - Unseen Arena starter + CI"
git branch -M $BRANCH
git remote add origin https://github.com/$GH_USER/$REPO_NAME.git
git push -u origin $BRANCH

echo "Repo pushed. Enable Actions in GitHub if required. Then add secrets:"
echo " - KEYSTORE_BASE64  (base64 of your .jks file)"
echo " - KEYSTORE_PASSWORD"
echo " - KEY_ALIAS"
echo " - KEY_PASSWORD"
echo "After adding secrets, go to Actions → run workflow (or push a commit) to build APK."
