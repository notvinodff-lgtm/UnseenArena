import 'package:flutter/material.dart';
import 'tournament_detail.dart';

class TournamentsScreen extends StatelessWidget {
  final List<Map<String, dynamic>> mockTournaments = [
    {
      'id': 't1',
      'title': 'Cobra Clash - Squad',
      'type': 'Squad',
      'entry_fee': 20,
      'prize_pool': 200,
      'time': '2025-11-10 18:00'
    },
    {
      'id': 't2',
      'title': 'Rookie Royale - Solo',
      'type': 'Solo',
      'entry_fee': 5,
      'prize_pool': 50,
      'time': '2025-11-12 20:00'
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Tournaments')),
      body: ListView.builder(
        padding: EdgeInsets.all(12),
        itemCount: mockTournaments.length,
        itemBuilder: (context, idx) {
          final t = mockTournaments[idx];
          return Card(
            child: ListTile(
              title: Text(t['title']),
              subtitle: Text('\${t['type']} • Entry: \${t['entry_fee']} coins • \${t['time']}'),
              trailing: ElevatedButton(
                child: Text('View'),
                onPressed: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => TournamentDetail(tournament: t)
                )),
              ),
            ),
          );
        },
      ),
    );
  }
}
