import 'package:flutter/material.dart';

class TournamentDetail extends StatelessWidget {
  final Map<String, dynamic> tournament;
  TournamentDetail({required this.tournament});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tournament['title'])),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Type: \${tournament['type']}', style: TextStyle(fontSize: 16)),
            SizedBox(height:8),
            Text('Entry Fee: \${tournament['entry_fee']} coins'),
            SizedBox(height:8),
            Text('Prize Pool: \${tournament['prize_pool']} coins'),
            SizedBox(height:8),
            Text('Time: \${tournament['time']}'),
            SizedBox(height:16),
            ElevatedButton(
              child: Text('Join Match (Mock Payment)'),
              onPressed: () {
                // This is a mock. Replace with Razorpay / actual payment flow.
                showDialog(context: context, builder: (_) => AlertDialog(
                  title: Text('Payment'),
                  content: Text('This is a mock payment. Implement Razorpay integration on backend and client.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: Text('OK')),
                  ],
                ));
              },
            ),
            SizedBox(height:12),
            Text('Rules:'),
            Expanded(child: SingleChildScrollView(child: Text('- Follow the rules. Upload screenshots after match.'))),
          ],
        ),
      ),
    );
  }
}
