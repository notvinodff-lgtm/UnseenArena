import 'package:flutter/material.dart';

class AdminDashboard extends StatefulWidget {
  @override
  _AdminDashboardState createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final TextEditingController _id = TextEditingController();
  final TextEditingController _pass = TextEditingController();
  bool logged = false;

  // demo credentials
  final demoId = 'admin';
  final demoPass = 'password123';

  @override
  Widget build(BuildContext context) {
    if (!logged) {
      return Scaffold(
        appBar: AppBar(title: Text('Admin Login')),
        body: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              TextField(controller: _id, decoration: InputDecoration(labelText: 'Admin ID')),
              TextField(controller: _pass, decoration: InputDecoration(labelText: 'Password'), obscureText: true),
              SizedBox(height:12),
              ElevatedButton(
                child: Text('Login'),
                onPressed: () {
                  if (_id.text == demoId && _pass.text == demoPass) {
                    setState(() { logged = true; });
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Invalid credentials (demo)')));
                  }
                },
              )
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text('Admin Dashboard')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Admin Controls', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height:8),
            ElevatedButton(onPressed: () {
              // Implement create tournament flow
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Create tournament (implement)')));
            }, child: Text('Create Tournament')),
            ElevatedButton(onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('View reports (implement)')));
            }, child: Text('View Reports')),
            ElevatedButton(onPressed: () {
              setState(() { logged = false; });
            }, child: Text('Logout')),
          ],
        ),
      ),
    );
  }
}
