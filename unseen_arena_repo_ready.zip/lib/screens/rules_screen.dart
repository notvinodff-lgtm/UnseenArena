import 'package:flutter/material.dart';

class RulesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Rules & Regulations')),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          Text('General Rules', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(height:8),
          Text('1. Only players with Free Fire level 40 or above are eligible to join tournament rooms.'),
          Text('2. Use only your registered Free Fire UID for all matches.'),
          Text('3. Room ID & Password will be shared 10 minutes before match start.'),
          Text('4. Late joiners will not be refunded.'),
          Text('5. Teaming up with enemies or using third-party tools / hacks / emulators is strictly prohibited.'),
          Text('6. Abusive or toxic behavior in chat or during matches will lead to a ban.'),
          Text('7. Players may be asked for match proof or screen recording in finals or disputes.'),
          Text('8. One account = one player. Multiple accounts will be permanently banned.'),
          SizedBox(height: 16),
          Text('Scoring System', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          DataTable(columns: [
            DataColumn(label: Text('Placement')),
            DataColumn(label: Text('Points')),
          ], rows: [
            DataRow(cells: [DataCell(Text('1st')), DataCell(Text('15'))]),
            DataRow(cells: [DataCell(Text('2nd')), DataCell(Text('12'))]),
            DataRow(cells: [DataCell(Text('3rd')), DataCell(Text('10'))]),
            DataRow(cells: [DataCell(Text('4th')), DataCell(Text('8'))]),
            DataRow(cells: [DataCell(Text('5th')), DataCell(Text('6'))]),
            DataRow(cells: [DataCell(Text('6-10th')), DataCell(Text('4'))]),
            DataRow(cells: [DataCell(Text('Kill')), DataCell(Text('+2 per kill'))]),
          ]),
          SizedBox(height:16),
          ElevatedButton(
            child: Text('Back'),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }
}
