import 'package:flutter/material.dart';
import 'screens/rules_screen.dart';
import 'screens/tournaments_screen.dart';
import 'screens/admin_dashboard.dart';

void main() {
  runApp(UnseenArenaApp());
}

class UnseenArenaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Unseen Arena',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      home: HomeWrapper(),
      routes: {
        '/rules': (_) => RulesScreen(),
        '/tournaments': (_) => TournamentsScreen(),
        '/admin': (_) => AdminDashboard(),
      },
    );
  }
}

class HomeWrapper extends StatefulWidget {
  @override
  _HomeWrapperState createState() => _HomeWrapperState();
}

class _HomeWrapperState extends State<HomeWrapper> {
  bool loggedIn = false;
  bool isAdmin = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Unseen Arena')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              child: Text('View Rules'),
              onPressed: () => Navigator.pushNamed(context, '/rules'),
            ),
            SizedBox(height: 12),
            ElevatedButton(
              child: Text('Browse Tournaments'),
              onPressed: () => Navigator.pushNamed(context, '/tournaments'),
            ),
            SizedBox(height: 12),
            ElevatedButton(
              child: Text('Admin Login (demo)'),
              onPressed: () => Navigator.pushNamed(context, '/admin'),
            ),
            SizedBox(height: 24),
            Text(
              'Note: This is a starter scaffold. You must connect Firebase and payment providers.',
              style: TextStyle(color: Colors.grey[700]),
            ),
          ],
        ),
      ),
    );
  }
}
