
# Repo Ready Package — Unseen Arena

This package contains the Flutter starter scaffold plus a GitHub Actions workflow that builds a release APK.

## Quick flow (recommended)
1. Extract this ZIP on your local machine.
2. Install Git and GitHub CLI (gh) and authenticate: `gh auth login`
3. Create a repo and push using the helper script:
   ```
   cd path/to/extracted
   ./dev-scripts/push_to_github.sh unseen-arena notvinodff-lgtm main
   ```
4. On GitHub, go to Settings → Secrets → Actions and add:
   - KEYSTORE_BASE64 : `base64 unseen_arena.jks` output (paste)
   - KEYSTORE_PASSWORD
   - KEY_ALIAS
   - KEY_PASSWORD
5. Trigger the workflow from Actions tab or push a new commit. After workflow completes, download the APK artifact.

## If you don't have a keystore
Create one locally:
```
keytool -genkey -v -keystore unseen_arena.jks -alias unseen_arena_key -keyalg RSA -keysize 2048 -validity 10000
```
Then run:
```
base64 unseen_arena.jks > unseen_arena.jks.base64.txt
# copy contents to KEYSTORE_BASE64 secret
```

## Notes
- Replace the placeholder demo admin credentials in `lib/screens/admin_dashboard.dart`.
- Add your `google-services.json` to `android/app/` if you use Firebase.
- Configure Razorpay / Paytm server-side for payments.

