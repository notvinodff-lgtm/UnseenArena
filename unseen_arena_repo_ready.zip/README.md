# Unseen Arena — Starter Flutter Project (Scaffold)

This is a **starter scaffold** for the Unseen Arena tournament app. It includes:

- Minimal Flutter app structure (`lib/main.dart`) with screens:
  - Login (email/phone mock)
  - Rules screen (includes level-40 rule)
  - Tournaments list (mock data)
  - Tournament detail + Join flow (mock payment stub)
  - Admin login (configurable id/pass) and simple admin dashboard

- Instructions to connect Firebase and Razorpay (placeholders)
- How to build an APK locally

**Important:** This is a scaffold / starter. To produce a production-ready APK you must:
1. Install Flutter SDK and Android SDK.
2. Replace placeholder Firebase config and Razorpay keys.
3. Implement backend (Firebase functions or Node.js) for authentication, payments verification, match result verification, anti-cheat, and storage.
4. Thoroughly test, secure API keys, and follow Play Store guidelines.

## Quick build steps (locally)
1. Install Flutter: https://flutter.dev
2. From this project's root directory run:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
3. The release APK will be in `build/app/outputs/flutter-apk/app-release.apk`

## Firebase setup (high level)
1. Create Firebase project.
2. Add Android app to Firebase and download `google-services.json` to `android/app/`.
3. Enable Firestore, Firebase Auth (Email/Phone), and Storage.
4. Update `lib/services/firebase_service.dart` placeholders with actual initialization if needed.

## Razorpay setup (high level)
1. Create Razorpay account and get Key ID / Key Secret.
2. Use Razorpay Flutter plugin or integrate via native platform channels.
3. Server must create orders and verify signatures.

## Files included
- lib/main.dart
- lib/screens/rules_screen.dart
- lib/screens/tournaments_screen.dart
- lib/screens/tournament_detail.dart
- lib/screens/admin_dashboard.dart
- pubspec.yaml

---
